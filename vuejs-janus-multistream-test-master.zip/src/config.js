export default {
  baseUrl: 'rtsp://172.16.14.84:554/',
  realm: '4201550086'
}
