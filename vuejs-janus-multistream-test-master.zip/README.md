Janus Vue Multistream - Vue + Meetecho Janus with multiple streaming sample
